-- THE WILD APPERELS: customer directory for admin panel
-- Run in Supabase SQL Editor. Does not alter existing customer accounts or orders.
BEGIN;
CREATE TABLE IF NOT EXISTS public.customer_profiles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.customer_profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Customers view own profile" ON public.customer_profiles;
CREATE POLICY "Customers view own profile" ON public.customer_profiles
  FOR SELECT TO authenticated USING (user_id = (SELECT auth.uid()) OR (SELECT public.is_wild_admin()));
DROP POLICY IF EXISTS "Customers update own profile" ON public.customer_profiles;
CREATE POLICY "Customers update own profile" ON public.customer_profiles
  FOR UPDATE TO authenticated USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));
DROP POLICY IF EXISTS "Admin views all customer profiles" ON public.customer_profiles;
CREATE POLICY "Admin views all customer profiles" ON public.customer_profiles
  FOR SELECT TO authenticated USING ((SELECT public.is_wild_admin()));
CREATE OR REPLACE FUNCTION public.sync_wild_customer_profile()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
BEGIN
  INSERT INTO public.customer_profiles(user_id, full_name, email, phone)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name',''),
    COALESCE(NEW.email,''),
    COALESCE(NEW.raw_user_meta_data->>'phone','')
  )
  ON CONFLICT (user_id) DO UPDATE SET
    full_name=EXCLUDED.full_name, email=EXCLUDED.email, phone=EXCLUDED.phone,
    updated_at=now();
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS on_auth_user_created_wild_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_wild_profile
AFTER INSERT OR UPDATE OF email, raw_user_meta_data ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.sync_wild_customer_profile();
-- Backfill all existing registered accounts into the directory.
INSERT INTO public.customer_profiles(user_id, full_name, email, phone, created_at)
SELECT id, COALESCE(raw_user_meta_data->>'full_name',''), COALESCE(email,''),
       COALESCE(raw_user_meta_data->>'phone',''), created_at
FROM auth.users
ON CONFLICT (user_id) DO UPDATE SET
  full_name=EXCLUDED.full_name, email=EXCLUDED.email, phone=EXCLUDED.phone;
GRANT SELECT, UPDATE ON public.customer_profiles TO authenticated;
COMMIT;
