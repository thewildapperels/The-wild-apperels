-- THE WILD APPERELS: Excel-backed pricing catalogue + admin quote permissions
-- Run this entire script once in Supabase SQL Editor.

-- Make the configured admin check reliable in database triggers and RLS.
CREATE OR REPLACE FUNCTION public.is_wild_admin()
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM auth.users
    WHERE id = (SELECT auth.uid())
      AND lower(email) = 'thattagaricharan@gmail.com'
      AND email_confirmed_at IS NOT NULL
  );
$$;
GRANT EXECUTE ON FUNCTION public.is_wild_admin() TO authenticated;

-- Keep the customer-response protection, but let the verified admin update quote fields.
CREATE OR REPLACE FUNCTION public.protect_customer_order_updates()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = ''
AS $$
BEGIN
  IF public.is_wild_admin() THEN
    NEW.updated_at := now();
    RETURN NEW;
  END IF;

  IF OLD.customer_id <> (SELECT auth.uid())
     OR OLD.quote_status <> 'pending'
     OR NEW.quote_status NOT IN ('accepted','rejected')
     OR NEW.status NOT IN ('accepted','rejected')
     OR NEW.id IS DISTINCT FROM OLD.id
     OR NEW.customer_id IS DISTINCT FROM OLD.customer_id
     OR NEW.customer_name IS DISTINCT FROM OLD.customer_name
     OR NEW.phone IS DISTINCT FROM OLD.phone
     OR NEW.email IS DISTINCT FROM OLD.email
     OR NEW.delivery_address IS DISTINCT FROM OLD.delivery_address
     OR NEW.notes IS DISTINCT FROM OLD.notes
     OR NEW.quote_amount IS DISTINCT FROM OLD.quote_amount
     OR NEW.quote_note IS DISTINCT FROM OLD.quote_note
     OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'Customers may only accept or reject their own pending quotation';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

-- Admin-only storage for the uploaded workbook's four sheets as JSON.
CREATE TABLE IF NOT EXISTS public.wild_pricing_catalog (
  id integer PRIMARY KEY CHECK (id = 1),
  source_name text NOT NULL,
  workbook_data jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.wild_pricing_catalog ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Wild admin manages pricing catalogue" ON public.wild_pricing_catalog;
CREATE POLICY "Wild admin manages pricing catalogue"
ON public.wild_pricing_catalog
FOR ALL TO authenticated
USING (public.is_wild_admin())
WITH CHECK (public.is_wild_admin());
GRANT SELECT, INSERT, UPDATE, DELETE ON public.wild_pricing_catalog TO authenticated;

-- Ensure an explicit admin update policy exists for quotation management.
DROP POLICY IF EXISTS "Configured admin can update all orders" ON public.orders;
CREATE POLICY "Configured admin can update all orders"
ON public.orders FOR UPDATE TO authenticated
USING (public.is_wild_admin())
WITH CHECK (public.is_wild_admin());

-- Admin may read customer profiles (the user-specific customer policy remains in place).
DROP POLICY IF EXISTS "Configured admin can view all customer profiles" ON public.customer_profiles;
CREATE POLICY "Configured admin can view all customer profiles"
ON public.customer_profiles FOR SELECT TO authenticated
USING (public.is_wild_admin());
