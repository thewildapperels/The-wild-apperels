-- THE WILD APPERELS: secure admin access + collection manager
-- Run in Supabase Dashboard > SQL Editor AFTER creating your admin Auth user.
-- Then replace YOUR_ADMIN_AUTH_USER_UUID below with that user's UUID from
-- Authentication > Users, and run the INSERT statement.

create extension if not exists pgcrypto;

-- Only users listed here can write to products, collections or image storage.
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
grant select on public.admin_users to authenticated;
drop policy if exists "Admins can verify own admin membership" on public.admin_users;
create policy "Admins can verify own admin membership"
on public.admin_users for select to authenticated
using (user_id = auth.uid());

-- Add the intended administrator (uncomment and replace the UUID first).
-- insert into public.admin_users(user_id) values ('YOUR_ADMIN_AUTH_USER_UUID')
-- on conflict (user_id) do nothing;

create table if not exists public.collection_items (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('fabric','zip','elastic','pack','label','tag')),
  code text not null,
  name text not null,
  quality text not null default '',
  spec text not null default '',
  "use" text not null default '',
  image_urls text[] not null default '{}',
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(type, code)
);
alter table public.collection_items enable row level security;
grant select, insert, update, delete on public.collection_items to anon, authenticated;
drop policy if exists "Public can view published collection items" on public.collection_items;
drop policy if exists "Signed-in admins can view all collection items" on public.collection_items;
drop policy if exists "Signed-in admins can insert collection items" on public.collection_items;
drop policy if exists "Signed-in admins can update collection items" on public.collection_items;
drop policy if exists "Signed-in admins can delete collection items" on public.collection_items;
create policy "Public can view published collection items"
on public.collection_items for select to anon, authenticated using (active = true);
create policy "Admins can view all collection items"
on public.collection_items for select to authenticated
using (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));
create policy "Admins can insert collection items"
on public.collection_items for insert to authenticated
with check (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));
create policy "Admins can update collection items"
on public.collection_items for update to authenticated
using (exists (select 1 from public.admin_users au where au.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));
create policy "Admins can delete collection items"
on public.collection_items for delete to authenticated
using (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));

-- Public image buckets; only allowlisted admins may upload/change/delete.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('material-images','material-images',true,10485760,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true,file_size_limit=10485760,
allowed_mime_types=array['image/jpeg','image/png','image/webp'];

drop policy if exists "Anyone can view material images" on storage.objects;
drop policy if exists "Signed-in admins can upload material images" on storage.objects;
drop policy if exists "Signed-in admins can update material images" on storage.objects;
drop policy if exists "Signed-in admins can delete material images" on storage.objects;
create policy "Anyone can view material images"
on storage.objects for select to anon, authenticated using (bucket_id='material-images');
create policy "Allowlisted admins upload material images"
on storage.objects for insert to authenticated
with check (bucket_id='material-images' and exists (select 1 from public.admin_users au where au.user_id=auth.uid()));
create policy "Allowlisted admins update material images"
on storage.objects for update to authenticated
using (bucket_id='material-images' and exists (select 1 from public.admin_users au where au.user_id=auth.uid()))
with check (bucket_id='material-images' and exists (select 1 from public.admin_users au where au.user_id=auth.uid()));
create policy "Allowlisted admins delete material images"
on storage.objects for delete to authenticated
using (bucket_id='material-images' and exists (select 1 from public.admin_users au where au.user_id=auth.uid()));

-- Tighten product write access too (the original V3 SQL allowed every signed-in user).
drop policy if exists "Signed-in admins can view all products" on public.products;
drop policy if exists "Signed-in admins can insert products" on public.products;
drop policy if exists "Signed-in admins can update products" on public.products;
drop policy if exists "Signed-in admins can delete products" on public.products;
create policy "Allowlisted admins can view all products"
on public.products for select to authenticated
using (exists (select 1 from public.admin_users au where au.user_id=auth.uid()));
create policy "Allowlisted admins can insert products"
on public.products for insert to authenticated
with check (exists (select 1 from public.admin_users au where au.user_id=auth.uid()));
create policy "Allowlisted admins can update products"
on public.products for update to authenticated
using (exists (select 1 from public.admin_users au where au.user_id=auth.uid()))
with check (exists (select 1 from public.admin_users au where au.user_id=auth.uid()));
create policy "Allowlisted admins can delete products"
on public.products for delete to authenticated
using (exists (select 1 from public.admin_users au where au.user_id=auth.uid()));

-- Product image bucket write policies are also restricted to allowlisted admins.
drop policy if exists "Signed-in admins can upload product images" on storage.objects;
drop policy if exists "Signed-in admins can update product images" on storage.objects;
drop policy if exists "Signed-in admins can delete product images" on storage.objects;
create policy "Allowlisted admins upload product images"
on storage.objects for insert to authenticated
with check (bucket_id='product-images' and exists (select 1 from public.admin_users au where au.user_id=auth.uid()));
create policy "Allowlisted admins update product images"
on storage.objects for update to authenticated
using (bucket_id='product-images' and exists (select 1 from public.admin_users au where au.user_id=auth.uid()))
with check (bucket_id='product-images' and exists (select 1 from public.admin_users au where au.user_id=auth.uid()));
create policy "Allowlisted admins delete product images"
on storage.objects for delete to authenticated
using (bucket_id='product-images' and exists (select 1 from public.admin_users au where au.user_id=auth.uid()));
