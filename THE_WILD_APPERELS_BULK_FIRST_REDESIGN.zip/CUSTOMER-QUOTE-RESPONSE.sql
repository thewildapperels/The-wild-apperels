-- Allows a customer to accept/reject only their own pending quotation.
-- Run once in Supabase SQL Editor after the main ordering setup.

create or replace function public.protect_customer_order_updates()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
begin
  if public.is_wild_admin() then
    new.updated_at := now();
    return new;
  end if;

  if old.customer_id <> auth.uid()
     or old.quote_status <> 'pending'
     or new.quote_status not in ('accepted','rejected')
     or new.status not in ('accepted','rejected')
     or new.id is distinct from old.id
     or new.customer_id is distinct from old.customer_id
     or new.customer_name is distinct from old.customer_name
     or new.phone is distinct from old.phone
     or new.email is distinct from old.email
     or new.delivery_address is distinct from old.delivery_address
     or new.notes is distinct from old.notes
     or new.quote_amount is distinct from old.quote_amount
     or new.quote_note is distinct from old.quote_note
     or new.created_at is distinct from old.created_at then
    raise exception 'Customers may only accept or reject their own pending quotation';
  end if;

  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists protect_customer_order_updates on public.orders;
create trigger protect_customer_order_updates
before update on public.orders
for each row execute function public.protect_customer_order_updates();

drop policy if exists "Customers respond to own quotations" on public.orders;
create policy "Customers respond to own quotations"
on public.orders for update to authenticated
using (customer_id = (select auth.uid()) and quote_status = 'pending')
with check (
  customer_id = (select auth.uid())
  and quote_status in ('accepted','rejected')
  and status in ('accepted','rejected')
);
