// Public browser credentials. Database access is enforced by Supabase RLS.
window.WILD_SUPABASE_CONFIG = {
  url: "https://dyxcntlwhvpjivfndqbr.supabase.co",
  anonKey: "sb_publishable_oGkdws-E1EjQarjlgmGStQ_BFWUar2v"
};
