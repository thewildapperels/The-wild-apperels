-- THE WILD APPERELS: Shop by Industry cover-image manager
-- Run once in Supabase Dashboard > SQL Editor.
-- Requires the existing admin_users table and material-images storage bucket
-- created by ADMIN-SECURITY-AND-COLLECTIONS.sql.

create table if not exists public.industry_collection_cards (
  card_key text primary key check (card_key in ('education','hospitality','corporate','sportswear','promotional','accessories')),
  title text not null,
  cover_image_url text,
  updated_at timestamptz not null default now()
);

alter table public.industry_collection_cards enable row level security;
grant select on public.industry_collection_cards to anon, authenticated;
grant insert, update on public.industry_collection_cards to authenticated;

drop policy if exists "Anyone can view industry collection cards" on public.industry_collection_cards;
drop policy if exists "Admins can insert industry collection cards" on public.industry_collection_cards;
drop policy if exists "Admins can update industry collection cards" on public.industry_collection_cards;

create policy "Anyone can view industry collection cards"
on public.industry_collection_cards for select to anon, authenticated
using (true);

create policy "Admins can insert industry collection cards"
on public.industry_collection_cards for insert to authenticated
with check (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));

create policy "Admins can update industry collection cards"
on public.industry_collection_cards for update to authenticated
using (exists (select 1 from public.admin_users au where au.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));
