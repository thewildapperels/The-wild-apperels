-- THE WILD APPERELS: Supabase setup
-- Run this whole script in Supabase Dashboard > SQL Editor > New query.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  description text not null default '',
  fabric text not null default '',
  gsm text not null default '',
  colours text[] not null default '{}',
  sizes text[] not null default '{}',
  image_urls text[] not null default '{}',
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.products enable row level security;

drop policy if exists "Public can view published products" on public.products;
create policy "Public can view published products"
on public.products for select
to anon, authenticated
using (active = true);

drop policy if exists "Signed-in admins can view all products" on public.products;
create policy "Signed-in admins can view all products"
on public.products for select
to authenticated
using (true);

drop policy if exists "Signed-in admins can insert products" on public.products;
create policy "Signed-in admins can insert products"
on public.products for insert
to authenticated
with check (auth.uid() is not null);

drop policy if exists "Signed-in admins can update products" on public.products;
create policy "Signed-in admins can update products"
on public.products for update
to authenticated
using (auth.uid() is not null)
with check (auth.uid() is not null);

drop policy if exists "Signed-in admins can delete products" on public.products;
create policy "Signed-in admins can delete products"
on public.products for delete
to authenticated
using (auth.uid() is not null);

-- Public image bucket. Only signed-in users can upload, change or delete images.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 10485760, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 10485760,
  allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "Anyone can view product images" on storage.objects;
create policy "Anyone can view product images"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'product-images');

drop policy if exists "Signed-in admins can upload product images" on storage.objects;
create policy "Signed-in admins can upload product images"
on storage.objects for insert
to authenticated
with check (bucket_id = 'product-images' and auth.uid() is not null);

drop policy if exists "Signed-in admins can update product images" on storage.objects;
create policy "Signed-in admins can update product images"
on storage.objects for update
to authenticated
using (bucket_id = 'product-images' and auth.uid() is not null)
with check (bucket_id = 'product-images' and auth.uid() is not null);

drop policy if exists "Signed-in admins can delete product images" on storage.objects;
create policy "Signed-in admins can delete product images"
on storage.objects for delete
to authenticated
using (bucket_id = 'product-images' and auth.uid() is not null);
